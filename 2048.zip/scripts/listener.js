
function Listener({ move: moveFn, start: startFn }) {
    window.addEventListener('keyup', function(e) {
        switch (e.keyCode) {
            //这些数字是可用查阅，也可用通过console.log(e.keyCode);打印获取
                //每个数字对应的是键盘按键的keycode
                //这里是事件回调，即将监听键盘按下后的动作打印到moveFn,然后返回到manager.js里
                //采用向量的方式来表示，这是计算机所使用的方式
            case 38:
                moveFn({ row: -1, column: 0 });
                break;
            case 37:
                moveFn({ row: 0, column: -1 });
                break;
            case 39:
                moveFn({ row: 0, column: 1 });
                break;
            case 40:
                moveFn({ row: 1, column: 0 });
                break;
        }
    });

    const buttons = document.querySelectorAll('button');
    for (let i = 0; i < buttons.length; i++) {
        buttons[i].addEventListener('click', function() {
            //startFn，触发跳转到manager.js里的self.start,进而跳转到start()，重新初始化游戏
            startFn();
        });
    }
}