var app = new Vue({
    el:"#app",
    data:{
        city:'',
        weatherlist:[]
    },
    methods:{
        searchweather:function () {
            //保存数据,每次请求，this的指向都会改表,因此需要用一个变量来保存
            //this对象在程序中随时会改变，而var that=this之后，that没改变之前仍然是指向当时的this，这样就不会出现找不到原来的对象。
            var that = this;

            //调用接口
            axios.get('http://wthrcdn.etouch.cn/weather_mini?city=' + this.city)
                .then(function (response) {
                    console.log(response.data.data.forecast);
                    that.weatherlist = response.data.data.forecast;

                })
                .catch(function (err) {
                })
        },
        changecity:function (city) {
            this.city = city;
            this.searchweather();

        }
    },
})