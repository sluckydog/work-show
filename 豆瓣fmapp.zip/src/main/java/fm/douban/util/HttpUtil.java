package fm.douban.util;

import com.alibaba.fastjson.JSON;
import fm.douban.spider.SubjectSpider;
import okhttp3.*;

import java.util.Map;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.FormBody.Builder;
import okhttp3.Request;

public class HttpUtil {

    public static Map<String,String> builderHeaderData(String refer, String host){

        Map<String,String> header=new HashMap<>();
//        进行存储
        header.put("Referer",refer);
        header.put("Host",host);
        return header;

    }

    public static String getContent(String url,Map<String,String> header){

        OkHttpClient okHttpClient = new OkHttpClient();
        Request.Builder request =new Request.Builder();
        for (Map.Entry<String, String> entry : header.entrySet()) {
            request.addHeader(entry.getKey(),entry.getValue());
        }
        request.url(url);
        Request request1 =request.build();

        String result=null;
        try {
            Response response =okHttpClient.newCall(request1).execute();
            result =response.body().string();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }



    }



