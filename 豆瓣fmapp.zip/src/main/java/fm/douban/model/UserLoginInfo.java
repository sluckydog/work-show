package fm.douban.model;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

//登陆信息测试类
public class UserLoginInfo implements Serializable {
    @NotEmpty(message = "用户名不能为空")
    @Email(message = "邮箱格式不正确")
    private String name;
    @NotEmpty(message = "密码不能为空")
    private String password;
    private String mobile;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
