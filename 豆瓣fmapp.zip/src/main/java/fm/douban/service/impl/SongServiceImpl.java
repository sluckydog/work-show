package fm.douban.service.impl;

import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import fm.douban.model.Song;
import fm.douban.param.SongQueryParam;
import fm.douban.service.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.LongSupplier;
@Service
public class SongServiceImpl implements SongService {
    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public Song add(Song song) {
        if (song==null){
            return null;
        }
        String id =song.getId();
        if (mongoTemplate.findById(id,Song.class)!=null){
            return null;
        }
        return mongoTemplate.insert(song);
    }

    @Override
    public Song get(String songId) {
        if (StringUtils.hasText(songId)){
            return mongoTemplate.findById(songId,Song.class);
        }
        return null;
    }

    @Override
    public Page<Song> list(SongQueryParam songQueryParam) {
        if (songQueryParam==null){
            return null;
        }
        Criteria criteria =new Criteria();
        List<Criteria> criteriaList =new ArrayList<>();
        if (songQueryParam.getName()!=null){
            criteriaList.add(Criteria.where("name").is(songQueryParam.getName()));
        }
        if (songQueryParam.getLyrics()!=null){
            criteriaList.add(Criteria.where("lyrics").is(songQueryParam.getLyrics()));
        }
        if (songQueryParam.getCover()!=null){
            criteriaList.add(Criteria.where("cover").is(songQueryParam.getCover()));
        }
        if (songQueryParam.getUrl()!=null){
            criteriaList.add(Criteria.where("url").is(songQueryParam.getUrl()));
        }
        if (criteriaList.isEmpty()){
            return null;
        }
        criteria.andOperator(criteriaList.toArray(new Criteria[]{}));
        Query query =new Query(criteria);

        long count = mongoTemplate.count(query,Song.class);
        PageRequest pageable =PageRequest.of(songQueryParam.getPageNum()-1,songQueryParam.getPageSize());
        query.with(pageable);
        List<Song> songs = mongoTemplate.find(query,Song.class);
        Page<Song> pageResult = PageableExecutionUtils.getPage(songs, pageable, new LongSupplier() {
            @Override
            public long getAsLong() {
                return count;
            }
        });


        return pageResult;
    }

    @Override
    public boolean modify(Song song) {
        if (song==null||!StringUtils.hasText(song.getId())){
            return false;
        }
        Query query = new Query(Criteria.where("id").is(song.getId()));
        Update updateData = new Update();
        if (song.getName()!=null){
            updateData.set("name",song.getName());
        }
        if (song.getLyrics()!=null){
            updateData.set("lyrics",song.getLyrics());
        }
        if (song.getCover()!=null){
            updateData.set("cover",song.getCover());
        }
        if (song.getUrl()!=null){
            updateData.set("url",song.getUrl());
        }
        if (song.getSingerIds()!=null){
            updateData.set("singerIds",song.getSingerIds());
        }
        updateData.set("gmtModified", LocalDateTime.now());
        UpdateResult result = mongoTemplate.updateFirst(query,updateData,Song.class);
        return result!=null&&result.getModifiedCount()>0;


    }

    @Override
    public boolean delete(String songId) {
        if (StringUtils.hasText(songId)){
            Song song = new Song();
            song.setId(songId);
            DeleteResult result = mongoTemplate.remove(song);
            return result!=null&&result.getDeletedCount()>0;
        }
        return false;
    }
}
