package fm.douban.service.impl;

import com.mongodb.client.result.DeleteResult;
import fm.douban.model.Favorite;
import fm.douban.service.FavoriteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
@Service
public class FavoriteServiceImpl implements FavoriteService {
    @Autowired
    private MongoTemplate mongoTemplate;
    @Override
    public Favorite add(Favorite fav) {
        if (fav==null){
            return null;
        }
        String id =fav.getId();
        if (mongoTemplate.findById(id,Favorite.class)!=null){
            return null;
        }
        return mongoTemplate.insert(fav);
    }

    @Override
    public List<Favorite> list(Favorite favParam) {
        if (favParam==null){
            return null;
        }
        Criteria criteria =new Criteria();
        List<Criteria> criteriaList =new ArrayList<>();

        if (favParam.getItemType()!=null){
            criteriaList.add(Criteria.where("itemType").is(favParam.getItemType()));
        }
        if (favParam.getItemId()!=null){
            criteriaList.add(Criteria.where("itemId").is(favParam.getItemId()));
        }
        if (favParam.getType()!=null){
            criteriaList.add(Criteria.where("type").is(favParam.getType()));
        }
        if (favParam.getUserId()!=null){
            criteriaList.add(Criteria.where("url").is(favParam.getUserId()));
        }
        if (criteriaList.isEmpty()){
            return mongoTemplate.findAll(Favorite.class);
        }
        criteria.andOperator(criteriaList.toArray(new Criteria[]{}));
        Query query =new Query(criteria);
        return mongoTemplate.find(query,Favorite.class);
    }

    @Override
    public boolean delete(Favorite favParam) {
        if (favParam==null){
            return false;
        }
        if (!StringUtils.hasText(favParam.getId())){
            return false;
        }
        Query query =new Query(Criteria.where("id").is(favParam.getId()));
        DeleteResult result =mongoTemplate.remove(query,Favorite.class);
        return result!=null&&result.getDeletedCount()>0;
    }
}
