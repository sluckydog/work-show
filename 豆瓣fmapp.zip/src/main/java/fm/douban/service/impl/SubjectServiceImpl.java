package fm.douban.service.impl;

import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import fm.douban.model.Subject;
import fm.douban.service.SubjectService;
import fm.douban.util.SubjectUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
@Service
public class SubjectServiceImpl implements SubjectService {
    @Autowired
    private MongoTemplate mongoTemplate;
    @Override
    public Subject addSubject(Subject subject) {
        if (subject==null){
            return null;
        }
        String id =subject.getId();
        if (mongoTemplate.findById(id,Subject.class)!=null){
            return null;
        }

        return mongoTemplate.insert(subject);
    }

    @Override
    public Subject get(String subjectId) {
        if (StringUtils.hasText(subjectId)){
            return mongoTemplate.findById(subjectId,Subject.class);
        }
        return null;
    }

    @Override
    public List<Subject> getSubjects(String type) {
        Subject subject =new Subject();
        subject.setSubjectType(type);
        return getSubjects(subject);
    }

    @Override
    public List<Subject> getSubjects(String type, String subType) {
        Subject subject =new Subject();
        subject.setSubjectType(type);
        subject.setSubjectSubType(subType);
        return  getSubjects(subject);

    }

    @Override
    public List<Subject> getSubjects(Subject subjectParam) {
        if (subjectParam==null){
            return null;
        }
        String type =subjectParam.getSubjectType();
        String subType =subjectParam.getSubjectSubType();
        Criteria criteria=new Criteria();
        List<Criteria> criteriaList =new ArrayList<>();

        if (SubjectUtil.TYPE_COLLECTION.equals(type)||SubjectUtil.TYPE_MHZ.equals(type)&&StringUtils.hasText(type)) {
            criteriaList.add(Criteria.where("subjectType").is(type));
        }
        if (SubjectUtil.TYPE_SUB_AGE.equals(subType)||SubjectUtil.TYPE_SUB_ARTIST.equals(subType)||SubjectUtil.TYPE_SUB_MOOD.equals(subType)||SubjectUtil.TYPE_SUB_STYLE.equals(subType)&&StringUtils.hasText(subType)){
            criteriaList.add(Criteria.where("subjectSubType").is(subType));
        }
        if (StringUtils.hasText(subjectParam.getMaster())){
            criteriaList.add(Criteria.where("master").is(subjectParam.getMaster()));
        }
        if (criteriaList.isEmpty()){
            return null;
        }
        criteria.andOperator(criteriaList.toArray(new Criteria[]{}));
        Query query =new Query(criteria);
        return  mongoTemplate.find(query,Subject.class);
    }

    @Override
    public boolean modify(Subject subject) {
        if (subject==null||!StringUtils.hasText(subject.getId())){
            return false;
        }
        Query query = new Query(Criteria.where("id").is(subject.getId()));
        Update updateData = new Update();
        if (subject.getCover()!=null){
            updateData.set("cover",subject.getCover());
        }
        if (subject.getDescription()!=null){
            updateData.set("description",subject.getDescription());
        }
        if (subject.getMaster()!=null){
            updateData.set("master",subject.getMaster());
        }
        if (subject.getName()!=null){
            updateData.set("name",subject.getName());
        }
        if (subject.getPublishedDate()!=null){
            updateData.set("publishedDate",subject.getPublishedDate());
        }
        if (subject.getSubjectType()!=null){
            updateData.set("subjectType",subject.getSubjectType());
        }
        if (subject.getSubjectSubType()!=null){
            updateData.set("sunjectSubType",subject.getSubjectSubType());
        }
        if (subject.getSongIds()!=null){
            updateData.set("songIds",subject.getSongIds());
        }
        UpdateResult result =mongoTemplate.updateFirst(query,updateData,Subject.class);
        return result!=null&&result.getModifiedCount()>0;
    }

    @Override
    public boolean delete(String subjectId) {
        if (StringUtils.hasText(subjectId)){
            Subject subject =new Subject();
            subject.setId(subjectId);
            DeleteResult result = mongoTemplate.remove(subject);
            return result!=null&&result.getDeletedCount()>0;
        }
        return false;
    }
}
