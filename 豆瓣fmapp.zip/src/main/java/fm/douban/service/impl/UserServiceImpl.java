package fm.douban.service.impl;

import com.mongodb.client.result.UpdateResult;
import fm.douban.model.UserLoginInfo;
import fm.douban.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public UserLoginInfo addUser(UserLoginInfo user) {
        if (user==null){
            return null;
        }
        String id =user.getMobile();
        if (!StringUtils.hasText(id)){
            return null;
        }
        Query query =new Query(Criteria.where("mobile").is(id));
        if (mongoTemplate.find(query,UserLoginInfo.class)!=null){
            return null;
        }
        return mongoTemplate.insert(user);//并没有说数据一定是完整的
    }

    @Override
    public UserLoginInfo getUser(String name) {
        if (!StringUtils.hasText(name)){
            return null;
        }
        Query query =new Query(Criteria.where("name").is(name));
        ;      if (mongoTemplate.find(query,UserLoginInfo.class)==null){
            return null;
        }
        return  mongoTemplate.find(query,UserLoginInfo.class).get(0);
    }

    @Override
    public boolean modify(UserLoginInfo user) {
        if (user==null){
            return false;
        }
        String id =user.getMobile();
        if (!StringUtils.hasText(id)){
            return false;
        }
        Query query =new Query(Criteria.where("mobile").is(id));

        Update updateData=new Update();
        if (StringUtils.hasText(user.getPassword())){
            updateData.set("password",user.getPassword());
        }
        UpdateResult result = mongoTemplate.updateFirst(query,updateData,UserLoginInfo.class);
        return result==null&&result.getModifiedCount()>0;

    }


}
