package fm.douban.service;

import fm.douban.model.Subject;

import java.util.List;

public interface SubjectService {
    //增加一个主题
    public Subject addSubject(Subject subject);
    //查询单个主题
    public Subject get(String subjectId);
    //查询一组主题
    public List<Subject> getSubjects(String type);
    //查询一组主题
    public List<Subject> getSubjects(String type ,String subType);
    //查询一组主题
    public List<Subject> getSubjects(Subject subjectParam);
    public boolean modify(Subject subject);
    //删除一个主题
    public boolean delete(String subjectId);
}
