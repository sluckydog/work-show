package fm.douban.service;

import fm.douban.model.Song;
import fm.douban.param.SongQueryParam;
import org.springframework.data.domain.Page;

public interface SongService {
    //增加一个歌曲
    public Song add(Song song);
    //根据id查询
    public Song get(String songId);
    //查询全部歌曲
    public Page<Song> list(SongQueryParam songQueryParam);
    //修改一首歌
    public boolean modify(Song song);
    //删除一首歌
    public boolean delete(String songId);
}
