package fm.douban.service;

import fm.douban.model.UserLoginInfo;

public interface UserService {
    //添加用户
    public UserLoginInfo addUser(UserLoginInfo user);
    //根据用户名获取用户
    public UserLoginInfo getUser(String name);
    //修改密码
    public boolean modify(UserLoginInfo user);



}
