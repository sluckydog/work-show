package fm.douban.app.control;

import fm.douban.model.Singer;
import fm.douban.service.SingerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/test/singer")
public class SingerTestControl {

    @Autowired
    private SingerService singerService;


    @GetMapping("/add")
    public Singer testAddSinger(){
        Singer singer = new Singer();
        singer.setGmtCreated(LocalDateTime.now());
        singer.setGmtModified(LocalDateTime.now());

        singer.setHomepage("1");
        singer.setName("S");
        singer.setId("1");
        List<String> list = new ArrayList<>();
        list.add("123456");
        list.add("djakdl");
        list.add("7987979");
        singer.setSimilarSingerIds(list);
        return singerService.addSinger(singer);
    }

    @GetMapping("/getAll")
    public List<Singer> testGetAll(){
        List<Singer> singers = singerService.getAll();
        return singers;

    }

    @GetMapping("/getOne")
    public Singer testGetSinger(){
        Singer singer = singerService.get("1");
        return singer;
    }

    @GetMapping("/modify")
    public  boolean testModifySinger(){
        Singer singer = new Singer();
        singer.setGmtCreated(LocalDateTime.now());
        singer.setGmtModified(LocalDateTime.now());

        singer.setId("1");
        singer.setHomepage("2");
        singer.setName("孙泽宇");
        List<String> list = new ArrayList<>();
        list.add("45646");
        list.add("48797");
        list.add("7jdkadjalj");
        singer.setSimilarSingerIds(list);
        return singerService.modify(singer);
    }

    @GetMapping("/del")
    public boolean testDelSinger(){
        return singerService.delete("1");

    }

}
