package fm.douban.app.control;

import fm.douban.model.Subject;
import fm.douban.service.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/test/subject")
public class SubjectTestControl {
    @Autowired
    private SubjectService subjectService;

    @GetMapping("/add")
    public Subject testAdd(){
        Subject subject=new Subject();
        subject.setId("0");
        subject.setCover("jay");
        subject.setDescription("杰伦天下第一");
        subject.setGmtCreated(LocalDateTime.now());
        subject.setGmtModified(LocalDateTime.now());
        subject.setSubjectType("mhz");
        subject.setSubjectSubType("mood");
        subject.setMaster("孙泽宇");
        subject.setName("流行");
        subject.setPublishedDate(LocalDate.now());
        List<String> songIds=new ArrayList<>();
        songIds.add("1323");
        songIds.add("4564487");
        songIds.add("7789addasd");
        subject.setSongIds(songIds);
        return subjectService.addSubject(subject);
    }
    @GetMapping("/get")
    public Subject testGet(){
        return subjectService.get("0");
    }
    @GetMapping("/getByType")
    public List<Subject> testGetByType(){
        return subjectService.getSubjects("mhz");
    }
    @GetMapping("/getBySubType")
    public List<Subject> testGetBySubType(){
        return subjectService.getSubjects("mhz","mood");
    }
    @GetMapping("/del")
    public boolean testDelete(){
        return subjectService.delete("0");
    }
}
