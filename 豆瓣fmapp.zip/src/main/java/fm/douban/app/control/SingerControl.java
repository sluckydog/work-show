package fm.douban.app.control;

import fm.douban.model.Singer;
import fm.douban.service.SingerService;
import fm.douban.service.SongService;
import fm.douban.service.SubjectService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;


@Controller
public class SingerControl {
    @Autowired
    private SongService songService;
    @Autowired
    private SingerService singerService;
    @Autowired
    private SubjectService subjectService;

    @GetMapping("/user-guide")
    public String myMhz(Model model){
//        调用随机歌手函数来处理，返回
        model.addAttribute("singers",randomSingers());
        return "userguide.html";

    }
//随机取歌手
    @GetMapping("/singer/random")
    @ResponseBody
    public List<Singer> randomSingers(){

        List<Singer> singers =singerService.getAll();
        Random random = new Random();
        List<Singer> singerList =new ArrayList<>();
        for (int i = 0; i <10 ; i++) {
            int number =random.nextInt(singers.size());
            singerList.add(singers.get(number));
            singers.remove(singers.get(number));
        }
        return singerList;

    }



}
