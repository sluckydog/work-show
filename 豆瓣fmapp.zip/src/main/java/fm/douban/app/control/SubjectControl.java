package fm.douban.app.control;

import fm.douban.model.Singer;
import fm.douban.model.Song;
import fm.douban.model.Subject;
import fm.douban.service.SingerService;
import fm.douban.service.SongService;
import fm.douban.service.SubjectService;
import fm.douban.util.SubjectUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class SubjectControl {

    @Autowired
    private SongService songService;
    @Autowired
    private SingerService singerService;
    @Autowired
    private SubjectService subjectService;
    @Autowired
    private MongoTemplate mongoTemplate;

    private static final Logger LOG = LoggerFactory.getLogger(SubjectControl.class);
    //艺术家详情
    @GetMapping("/artist")
    public String mhzDetail(Model model, @RequestParam(name="subjectId")String subjectId){
        Singer singer = singerService.get(subjectId);
        String singerId=singer.getId();
        List<Song> returnSongs=new ArrayList<>();

        List<Song> songList =mongoTemplate.findAll(Song.class);
        for (Song song:songList){
            if (song.getSingerIds().contains(singerId)){
                returnSongs.add(song);
            }
        }
        List<String> simSingerIds =singer.getSimilarSingerIds();
        List<Singer> returnSingers =new ArrayList<>();
        for (String singerId1:simSingerIds){
            returnSingers.add(singerService.get(singerId1));
        }
        model.addAttribute("singer",singer);
        model.addAttribute("songs",returnSongs);
        model.addAttribute("simSingers",returnSingers);
        return "mhzDetail";
    }

    //歌单列表
    @GetMapping("/collection")
    public String collection(Model model){
        //获取所有歌单数据
        //这里面有master ，有sample songs
        List<Subject> collectionList =subjectService.getSubjects(SubjectUtil.TYPE_COLLECTION);
        model.addAttribute("collections",collectionList);
        return "collection";
    }

    //歌单详情
    @GetMapping(path = "/collectiondetail")
    public String collectionDetail(Model model,@RequestParam("subjectId")String subjectId){
        //歌单的全部信息
        Subject subject =subjectService.get(subjectId);
        //歌手的全部信息
        String singerId =subject.getArtist_id();
        Singer singer =singerService.get(singerId);

        List<Song> songs =new ArrayList<>();
        ///歌曲的全部信息
        List<String> songIds=subject.getSongIds();
        if (songIds!=null){
            for (String songId:songIds){
                Song song =songService.get(songId);
                songs.add(song);
            }
        }

        //关联的其他歌单
        String singerName =subject.getMaster();
        Subject subject1 =new Subject();
        subject1.setMaster(singerName);
        List<Subject> otherSubjects = subjectService.getSubjects(subject1);


        model.addAttribute("subject",subject);
        model.addAttribute("singer",singer);
        model.addAttribute("songs",songs);
        model.addAttribute("otherSubjects",otherSubjects);
        return "collectiondetail";

    }


}
