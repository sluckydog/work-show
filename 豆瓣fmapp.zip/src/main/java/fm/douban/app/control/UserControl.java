package fm.douban.app.control;

import fm.douban.model.UserLoginInfo;
import fm.douban.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

@Controller
public class UserControl {

    @Autowired
    private UserService userService;
    //注册页
    @GetMapping(path = "sign")
    public String signPage(Model model){
        UserLoginInfo userLoginInfo =new UserLoginInfo();
        model.addAttribute("user",userLoginInfo);
        return "sign";
    }

    //提交注册
    @PostMapping(path = "register")
    @ResponseBody
    public Map registerAction(@Valid UserLoginInfo user,BindingResult result ,@RequestParam("password1")String password1, HttpServletResponse response){
        Map returnData =new HashMap();
        if (result.hasErrors()){
            String errMsg = result.getFieldError().getDefaultMessage();
            returnData.put("验证错误信息",errMsg);
            return returnData;
        }
        if (!user.getPassword().equals(password1)){
            returnData.put("message","两次密码不相等");
            return returnData;
        }
        userService.addUser(user);
        returnData.put("message","注册成功");
        return returnData;
    }

    //登陆页
    @GetMapping(path = "/login")
    public String loginPage(Model model){
        UserLoginInfo userLoginInfo =new UserLoginInfo();
        model.addAttribute("user",userLoginInfo);
        return "login";
    }

    //登陆操作
    @PostMapping(path = "/authenticate")
    @ResponseBody
    public Map login(@Valid UserLoginInfo user,BindingResult result, HttpServletRequest request, HttpServletResponse response){
        Map returnData =new HashMap();
        if (result.hasErrors()){
            String errMsg = result.getFieldError().getDefaultMessage();
            returnData.put("验证错误信息",errMsg);
        }
        UserLoginInfo userData =userService.getUser(user.getName());
        if (userData==null){
            returnData.put("result","找不到用户");
            return returnData;
        }
        //如果密码正确就记录session信息
        if(user.getPassword().equals(userData.getPassword())){
            HttpSession session =request.getSession();
            session.setAttribute("userSignInfo",user);
            returnData.put("result",userData);

        }else {
            returnData.put("result","密码不正确");

        }
        return  returnData;
    }

}
