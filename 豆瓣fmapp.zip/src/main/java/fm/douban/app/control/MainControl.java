package fm.douban.app.control;

import fm.douban.model.MhzViewModel;
import fm.douban.model.Singer;
import fm.douban.model.Song;
import fm.douban.model.Subject;
import fm.douban.param.SongQueryParam;
import fm.douban.service.FavoriteService;
import fm.douban.service.SingerService;
import fm.douban.service.SongService;
import fm.douban.service.SubjectService;
import fm.douban.util.SubjectUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * date: 2020/4/28 20:03
 *
 * @author fsw
 * QQ 1124813753
 */
@Controller
public class MainControl {
    @Autowired
    private SongService songService;
    @Autowired
    private SingerService singerService;
    @Autowired
    private SubjectService subjectService;
    @Autowired
    private FavoriteService favoriteService;

    @GetMapping("/index")
    public String index(Model model) {
        SongQueryParam songQueryParam =new SongQueryParam();
        songQueryParam.setPageNum(1);
        songQueryParam.setPageSize(1);
        songQueryParam.setName("Be With You");
        Page<Song> songs = songService.list(songQueryParam);
        List<Song> songList =songs.getContent();
        Song song =songList.get(0);
        List<Singer>singers =new ArrayList<>();
        for (String singerId:song.getSingerIds()){
            singers.add(singerService.get(singerId));
        }
        model.addAttribute("song",song);
        model.addAttribute("singers",singers);


//进行1.查询数据  查询所有的mhz，调用subservice 的get方法，参数使用util里设置好的
        List<Subject> subjectList =subjectService.getSubjects(SubjectUtil.TYPE_MHZ);


//    2.    准备4个list 用于存放不同的数据
        List<Subject> artistSubjectData =new ArrayList<>();
        List<Subject> ageSubjectData =new ArrayList<>();
        List<Subject> moodSubjectData =new ArrayList<>();
        List<Subject> styleSubjectData =new ArrayList<>();
//将第一步的数据进行遍历，
        for (Subject subject:subjectList){
            if(subject.getSubjectSubType().equals(SubjectUtil.TYPE_SUB_AGE)){
                ageSubjectData.add(subject);
            }
            if(subject.getSubjectSubType().equals(SubjectUtil.TYPE_SUB_MOOD)){

                moodSubjectData.add(subject);
            }
            if(subject.getSubjectSubType().equals(SubjectUtil.TYPE_SUB_STYLE)){

                styleSubjectData.add(subject);
            }
            if(subject.getSubjectSubType().equals(SubjectUtil.TYPE_SUB_ARTIST)){

                artistSubjectData.add(subject);
            }
        }

        //新建3个实例，作为区块进行整合
//        设置title
        MhzViewModel mhzViewModel =new MhzViewModel();
        mhzViewModel.setTitle("语言/年代");
        MhzViewModel mhzViewMode2 =new MhzViewModel();
        mhzViewMode2.setTitle("心情/场景");
        MhzViewModel mhzViewMode3 =new MhzViewModel();
        mhzViewMode3.setTitle("风格/流派");
//设置subject
        mhzViewModel.setSubjects(ageSubjectData);
        mhzViewMode2.setSubjects(moodSubjectData);
        mhzViewMode3.setSubjects(styleSubjectData);

//存入一个新的List<MhzViewModel>集合
        List<MhzViewModel> mhzViewModels =new ArrayList<>();

        mhzViewModels.add(mhzViewMode2);
        mhzViewModels.add(mhzViewModel);
        mhzViewModels.add(mhzViewMode3);
        model.addAttribute("title","从艺术家出发");
        model.addAttribute("artistDatas",artistSubjectData);
        model.addAttribute("mhzViewModels",mhzViewModels);


        return "index";
    }

    @GetMapping("/search")
    public String search(Model model){
        return "search";
    }

//    用于接收关键词进行搜索
    @GetMapping("/searchContent")
    @ResponseBody
    public Map searchContent(@RequestParam(name="keyword") String keyword){
        Map returnData =new HashMap();
        SongQueryParam songQueryParam =new SongQueryParam();
        songQueryParam.setName(keyword);
        List<Song> songs =songService.list(songQueryParam).getContent();
        returnData.put("songs",songs);
        return returnData;
    }



}
