package fm.douban.spider;

import com.alibaba.fastjson.JSON;
import fm.douban.model.Singer;
import fm.douban.model.Song;
import fm.douban.service.SingerService;
import fm.douban.service.SongService;
import fm.douban.service.SubjectService;
import fm.douban.util.HttpUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class SingerSongSpider {
    private  static final String Singer_pre ="https://fm.douban.com/j/v2/artist/";
    private  static final String Host="fm.douban.com";
    private  static final String Referer_pre ="https://fm.douban.com/artist/";
    //系统自动注入主题服务
    @Autowired
    private SubjectService subjectService;
    //系统自动注入歌手服务
    @Autowired
    private SingerService singerService;
    @Autowired
    private SongService songService;

    //系统启动的时候自动执行爬取任务
//    @PostConstruct
    public void init(){
        doExcute();
    }

    //开始执行爬取任务
    public void doExcute(){

        getSongDataBySingers();

    }
    //执行爬取歌手歌曲数据
    private void getSongDataBySingers(){
        List<Singer> singerList =singerService.getAll();
        for (Singer singer:singerList){
            String singerId =singer.getId();
            String url =Singer_pre+singerId;
            String Referer = Referer_pre+singerId;
            String result = HttpUtil.getContent(url,HttpUtil.builderHeaderData(Referer,Host));
            Map returnData = JSON.parseObject(result, Map.class);
            Map songListData =(Map) returnData.get("songlist");

            Map relatedData =(Map) returnData.get("related_channel");

            if (songListData==null){
                return;
            }
            List<Map> songsData = (List<Map>)songListData.get("songs");
            for (Map songData:songsData){
                Song song=new Song();
                song.setId(songData.get("sid").toString());
                song.setName(songData.get("title").toString());
                song.setCover(songData.get("picture").toString());
                song.setUrl(songData.get("url").toString());

                List<Map>singers =(List<Map>)songData.get("singers");
                List<String> singerIds = new ArrayList();
                for (Map singer1:singers){
                    Singer singer2 =new Singer();
                    singer2.setId(singer1.get("id").toString());
                    singer2.setName(singer1.get("name").toString());
                    singer2.setAvatar(singer1.get("avatar").toString());
                    singerService.addSinger(singer2);
                    singerIds.add(singer1.get("id").toString());
                }
                song.setSingerIds(singerIds);
                songService.add(song);

            }

            singer.setSimilarSingerIds(getRelatedSingers(relatedData));

        }
    }

    //执行爬取关联的歌手
    private  List<String> getRelatedSingers(Map resourceData){
        if (resourceData==null){
            return null;
        }
        List<Map> similarArtistsData = (List<Map>)resourceData.get("similar_artists");
        List<String> singerIds = new ArrayList<>();
        //把相似歌手储存起来
        for (Map similarArtistData:similarArtistsData){
            Singer singer = new Singer();
            singer.setId( similarArtistData.get("id").toString());
            singerIds.add(similarArtistData.get("id").toString());
            singer.setName(similarArtistData.get("name").toString());
            singer.setAvatar(similarArtistData.get("avatar").toString());
            singerService.addSinger(singer);
        }
        return singerIds;


    }

}
