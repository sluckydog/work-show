package fm.douban.spider;

import com.alibaba.fastjson.JSON;
import fm.douban.model.Singer;
import fm.douban.model.Song;
import fm.douban.model.Subject;
import fm.douban.service.SingerService;
import fm.douban.service.SongService;
import fm.douban.service.SubjectService;
import fm.douban.util.HttpUtil;
import fm.douban.util.SubjectUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Component
public class SubjectSpider {
    //主题请求
    private  static final String MHZAPI="https://fm.douban.com/j/v2/rec_channels?specific=all";
    //主题歌曲请求前缀
    private  static final String  SONG_URL="https://fm.douban.com/j/v2/playlist?channel=";
    //主题歌曲后缀
    private  static  final String SONG_fixed ="&kbps=128&client=s%3Amainsite%7Cy%3A3.0&app_name=radio_website&version=100&type=n";
    //歌曲API
    private static  final String CollectionAPI="https://douban.fm/j/v2/songlist/explore?type=hot&genre=0&limit=20&sample_cnt=5";
    private  static final String CollectionReferer ="https://fm.douban.com/explore/songlists";
    //指向
    private  static final String MHZReferer ="https://fm.douban.com/";
    //Host
    private  static final String Host="fm.douban.com";


    //系统自动注入主题服务
    @Autowired
    private SubjectService subjectService;
    //系统自动注入歌手服务
    @Autowired
    private SingerService singerService;
    @Autowired
    private SongService songService;

    //系统启动的时候自动执行爬取任务
    //@PostConstruct
    public void init(){
        doExcute();
    }

    //开始执行爬取任务
    public void doExcute(){

        getSubjectData();
        getCollectionsData();

    }
    //执行爬取主题数据
    private void getSubjectData(){
        String result =HttpUtil.getContent(MHZAPI,HttpUtil.builderHeaderData(MHZReferer,Host));
        Map returnSourceObj =JSON.parseObject(result,Map.class);
        Map returnData=(Map)returnSourceObj.get("data");
        Map channelsData =(Map)returnData.get("channels");

        List<Map> moods =(List<Map>)channelsData.get("scenario");
        List<Map> languages =(List<Map>)channelsData.get("language");
        List<Map> styles =(List<Map>)channelsData.get("genre");
        List<Map> artists =(List<Map>)channelsData.get("artist");
        //爬取主题的时候顺便根据主题id爬取主题歌曲
        //爬取艺术家的时候顺便把关联歌手的弄到
        for (Map subjectData:moods){
            Subject subject =new Subject();
            subject.setId(subjectData.get("id").toString());
            subject.setName(subjectData.get("name").toString());
            subject.setDescription(subjectData.get("intro").toString());
            subject.setPublishedDate(LocalDate.now());
            subject.setGmtModified(LocalDateTime.now());
            subject.setGmtCreated(LocalDateTime.now());
            subject.setCover(subjectData.get("cover").toString());
            subject.setSubjectType(SubjectUtil.TYPE_MHZ);
            subject.setSubjectSubType(SubjectUtil.TYPE_SUB_MOOD);
            subject.setMaster("豆瓣FM");
            //源数据没有歌曲id集合
            subjectService.addSubject(subject);

            getSubjectSongData(subjectData.get("id").toString());
        }
        for (Map subjectData:languages){
            Subject subject =new Subject();
            subject.setId(subjectData.get("id").toString());
            subject.setName(subjectData.get("name").toString());
            subject.setDescription(subjectData.get("intro").toString());
            subject.setPublishedDate(LocalDate.now());
            subject.setGmtModified(LocalDateTime.now());
            subject.setGmtCreated(LocalDateTime.now());
            subject.setCover(subjectData.get("cover").toString());
            subject.setSubjectType(SubjectUtil.TYPE_MHZ);
            subject.setSubjectSubType(SubjectUtil.TYPE_SUB_AGE);
            subject.setMaster("豆瓣FM");

            subjectService.addSubject(subject);
            getSubjectSongData(subjectData.get("id").toString());
        }
        for (Map subjectData:styles){
            Subject subject =new Subject();
            subject.setId(subjectData.get("id").toString());
            subject.setName(subjectData.get("name").toString());
            subject.setDescription(subjectData.get("intro").toString());
            subject.setPublishedDate(LocalDate.now());
            subject.setGmtModified(LocalDateTime.now());
            subject.setGmtCreated(LocalDateTime.now());
            subject.setCover(subjectData.get("cover").toString());
            subject.setSubjectType(SubjectUtil.TYPE_MHZ);
            subject.setSubjectSubType(SubjectUtil.TYPE_SUB_STYLE);
            subject.setMaster("豆瓣FM");
            subjectService.addSubject(subject);
            getSubjectSongData(subjectData.get("id").toString());
        }
        for (Map subjectData:artists){
            Subject subject =new Subject();
            subject.setId(subjectData.get("id").toString());
            subject.setName(subjectData.get("name").toString());
            subject.setDescription(subjectData.get("intro").toString());
            subject.setPublishedDate(LocalDate.now());
            subject.setGmtModified(LocalDateTime.now());
            subject.setGmtCreated(LocalDateTime.now());
            subject.setCover(subjectData.get("cover").toString());
            subject.setSubjectType(SubjectUtil.TYPE_MHZ);
            subject.setSubjectSubType(SubjectUtil.TYPE_SUB_ARTIST);
            subject.setMaster("豆瓣FM");
            subjectService.addSubject(subject);

            getSubjectSongData(subjectData.get("id").toString());

            List<Map> relatedSingers =(List<Map>)subjectData.get("related_artists");
            for (Map singerData:relatedSingers){
                Singer singer=new Singer();
                singer.setId(singerData.get("id").toString());
                singer.setAvatar(singerData.get("cover").toString());
                singer.setName(singerData.get("name").toString());
                singerService.addSinger(singer);
            }
        }


    }
    //执行爬取主题歌曲数据
    private void getSubjectSongData(String subjectId){
        String url = SONG_URL+subjectId+SONG_fixed;
        String result =HttpUtil.getContent(url,HttpUtil.builderHeaderData(MHZReferer,Host));
        Map returnData =JSON.parseObject(result,Map.class);
        List<Map> songsData =(List<Map>)returnData.get("song");
        for (Map songData:songsData){
            Song song =new Song();
            song.setId(songData.get("sid").toString());
            song.setUrl(songData.get("url").toString());
            song.setName(songData.get("title").toString());
            song.setCover(songData.get("picture").toString());

            List<Map>singers =(List<Map>)songData.get("singers");
            List<String> singerIds = new ArrayList();
            for (Map singer:singers){
                Singer singer1 =new Singer();
                singer1.setId(singer.get("id").toString());
                singer1.setName(singer.get("name").toString());
                singer1.setAvatar(singer.get("avatar").toString());
                singerService.addSinger(singer1);
                singerIds.add(singer.get("id").toString());
            }
            song.setSingerIds(singerIds);
            songService.add(song);
        }
    }

    //爬取歌单数据
    private void getCollectionsData(){
        String result =HttpUtil.getContent(CollectionAPI,HttpUtil.builderHeaderData(CollectionReferer,Host));
        List<Map> returnData =JSON.parseArray(result,Map.class);
        for (Map collection:returnData){
            Subject subject =new Subject();
            subject.setId(collection.get("id").toString());
            subject.setName(collection.get("title").toString());
            subject.setSubjectType(SubjectUtil.TYPE_COLLECTION);
            subject.setDescription(collection.get("description").toString());
            subject.setCover(collection.get("cover").toString());

            subjectService.addSubject(subject);

            Map creatorData =(Map)collection.get("creator");
            Singer singer =new Singer();
            singer.setId(creatorData.get("id").toString());
            singer.setAvatar(creatorData.get("picture").toString());
            singer.setHomepage(creatorData.get("url").toString());
            singer.setName(creatorData.get("name").toString());
            singerService.addSinger(singer);
        }
    }




}
